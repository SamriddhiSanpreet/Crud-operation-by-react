import React, { useEffect, useState } from 'react'

export default function Form() {

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [pass, setPass] = useState("");

    const [studentData, setStudentData] = useState([]);




    const handleForm = (e) => {
        e.preventDefault(); 

      
        if (!name || !email || !pass) {
            alert("All input fields are required")
            return;
        }

        fetch("http://localhost:9000/student", {
            method: "POST",
            body: JSON.stringify({ name, email, pass }),
            headers: { "Content-type": "application/json; charset=UTF-8" }
        })
            .then((res) => res.json())
            .then((data) => {
                getData()
                console.log(data, "data added successfully")
            })


        setName("");
        setEmail("")
        setPass("")

    }


   const getData = () =>{
    fetch("http://localhost:9000/student")
    .then((res) => res.json())
    .then((data) => {
        setStudentData(data)
        console.log(data)
    })
    .catch((err) => console.log("something is wrong ", err))

   }



    useEffect(() => {
        getData()
    }, [])


    const HandleDelete = (id) =>{
        fetch("http://localhost:9000/student/"+id,{
            method: "DELETE",
            body: JSON.stringify({ name, email, pass }),
            headers: { "Content-type": "application/json; charset=UTF-8" } 
        })
        .then((res) => res.json())
        .then((data) => {
            getData()
            console.log(data)
        })
        .catch((err) => console.log("something is wrong ", err))
    }

    return (
        <div style={{margin:"50px"}}>
            <h1 style={{marginBottom:"20px"}}>Form</h1>
            <form onSubmit={handleForm} >

                <input value={name} onChange={(e) => setName(e.target.value)} type="text" placeholder='Enter Your Name' />

                <br /><br />

                <input value={email} onChange={(e) => setEmail(e.target.value)} type="text" placeholder='Enter Your Email Address' />

                <br /><br />

                <input value={pass} onChange={(e) => setPass(e.target.value)} type="password" placeholder='Enter Your Password' /> <br /><br />

                <button>Add Data</button>
            </form>



            <div>
                {
                    studentData.map((item) => {
                        return <div key={item.id} style={{border:"2px solid #000",display:"inline-block", margin:"10px",padding:"20px 30px",borderRadius:"10px"}}>
                            <p style={{fontSize:"20px", textAlign:"center"}}>{item.id}</p>
                            <h3 style={{fontSize:"40px", textAlign:"center"}}>{item.name}</h3>
                            <h4 style={{fontSize:"40px", textAlign:"center"}}>{item.email}</h4>
                            <button onClick={()=>HandleDelete(item.id)} style={{marginLeft:"20px"}}>Delete</button>
                        </div>
                    })
                }
            </div>
        </div>
    )
}
