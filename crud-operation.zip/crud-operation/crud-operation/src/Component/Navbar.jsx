import React from 'react'
import { Link } from 'react-router-dom'

export default function Navbar() {
    return (
        <div style={{backgroundColor:"#000" , display:"flex",justifyContent:"space-around",padding:"20px 0"}}>
            <Link to="/" style={{textDecoration:"none", fontSize:"20px", color:"#fff"}}>Home</Link>
            <Link to="/form" style={{textDecoration:"none", fontSize:"20px", color:"#fff"}}>Form</Link>
        </div>
    )
}
